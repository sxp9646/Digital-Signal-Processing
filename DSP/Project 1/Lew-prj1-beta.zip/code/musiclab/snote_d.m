function snote_d(x,y,sz,a)
%SNOTE_D   draws a dotted sixteenth note for the Music GUI
%      (support function used in musicgui)
%    The dotted 16-th note plays 75% as long as an 8-th note.
% **NOT YET IMPLEMENTED **

error('16-th notes are not yet implemented')
