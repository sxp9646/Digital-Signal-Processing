function snote(x,y,sz,a)
%SNOTE   draws a sixteenth note for the Music GUI
%    (support function used in musicgui)
% **NOT YET IMPLEMENTED **

error('16-th notes are not yet implemented')
