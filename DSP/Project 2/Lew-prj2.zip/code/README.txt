Andy Lew

The two functions signals.m and project2_filtering.m are working as intended. 
Some of the final outputs are not completely clear.

To run signals.m:
=======================
1. Type in one of the commands below:
signals(0);
signals(1);
signals(2);
signals(3);
signals(4);

To run project2_filtering.m:
================================
1. Type in one of the commands below:
project2_filtering(1,1);
project2_filtering(2,1);
project2_filtering(0,0);
project2_filtering(1,0);
project2_filtering(2,0);
project2_filtering(3,0);